//########################################## PROTOTYPE ###############################################
String.prototype.contains = function(it) { return this.indexOf(it) != -1; };